import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';



@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.scss']
})
export class UserprofileComponent implements OnInit {
  userDetailsForm: FormGroup;
  submitted = false;
   @Input() selectedRowData;
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    console.log("SELECTED ", this.selectedRowData);

    this.userDetailsForm = this.formBuilder.group({
      firstName: [this.selectedRowData.first_name, Validators.required],
      lastName: [this.selectedRowData.last_name, Validators.required],
      email: [this.selectedRowData.email, [Validators.required, Validators.email]],
  });
  }
  get f() { return this.userDetailsForm.controls; }

  onSubmit(){
    this.submitted = true;
        // stop here if form is invalid
        if (this.userDetailsForm.invalid) {
          return;
      }

      alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.userDetailsForm.value))
  }
  
}
