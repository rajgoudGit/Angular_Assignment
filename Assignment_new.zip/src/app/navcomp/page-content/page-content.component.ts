import { Component, OnInit, ViewChild } from '@angular/core';
import { AuthenticationService } from 'app/services.service';
import {NgbTabset} from "@ng-bootstrap/ng-bootstrap";

@Component({
  selector: 'app-page-content',
  templateUrl: './page-content.component.html',
  styleUrls: ['./page-content.component.scss']
})
export class PageContentComponent implements OnInit {
  @ViewChild('tabs')
  private tabs:NgbTabset;
  public selectedRowData = [];
  constructor(private service: AuthenticationService) { }

  ngOnInit() {
    this.service.subject.subscribe( (res) =>
     { 
      if(this.tabs) {
       this.tabs.select('tabs-2');
      }
       this.selectedRowData = res;
      }
    )
  }

  onTabChange(e)
  {
    console.log(e);
  }

}
