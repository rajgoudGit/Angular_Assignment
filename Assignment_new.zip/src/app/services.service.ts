import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';

import { User } from '../app/models/users';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
     public subject:Subject<any> = new Subject();
    isSidebarPinned = false;
    isSidebarToggeled = false;
        
     private currentUserSubject: BehaviorSubject<User>;
     public currentUser: Observable<User>;


     private api = "https://reqres.in/api/users?page=2";
     httpOptions = {
       headers: new HttpHeaders({
         'Content-Type': 'application/json'
       })
     }      
    constructor(private http: HttpClient) {
        this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
        this.currentUser = this.currentUserSubject.asObservable();
    }

    public get currentUserValue(): User {
        return this.currentUserSubject.value;
    }

    login(email: string, password: string) {
        return this.http.post<any>('https://reqres.in/api/login', { email, password })
            .pipe(map(user => {
                // login successful if there's a jwt token in the response
                if (user && user.token) {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    localStorage.setItem('currentUser', JSON.stringify(user));
                    this.currentUserSubject.next(user);
                }

                return user;
            }));
    }

    // logout() {
    //     // remove user from local storage to log user out
    //     localStorage.removeItem('currentUser');
    //     this.currentUserSubject.next(null);
    // }

    getData(): Observable<any> {
      return this.http.get<any>(this.api);
    }


    toggleSidebar() {
        this.isSidebarToggeled = ! this.isSidebarToggeled;
        console.log(this.isSidebarToggeled);
      }
    
      toggleSidebarPin() {
        this.isSidebarPinned = ! this.isSidebarPinned;
      }
    
      getSidebarStat() {
        return {
          isSidebarPinned: this.isSidebarPinned,
          isSidebarToggeled: this.isSidebarToggeled
        }
      }
}