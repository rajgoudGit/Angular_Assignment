import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../services.service';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.scss']
})
export class UserlistComponent implements OnInit {
  ItemsArray =[
    // {
    //   "id" : "34",
    //   "name": "Rajesh",
    //   "email":"gmail@gmail.com",
    //   "phone": "12345",
    //   "address":"abc"
    // },
    // {
    //   "id" : "34",
    //   "name": "Rajesh",
    //   "email":"gmail@gmail.com",
    //   "phone": "12345",
    //   "address":"abc"
    // },
    // {
    //   "id" : "34",
    //   "name": "Rajesh",
    //   "email":"gmail@gmail.com",
    //   "phone": "12345",
    //   "address":"abc"
    // }
  ];
  constructor(private service: AuthenticationService) { }

  ngOnInit(): void {
    this.service.getData().subscribe((res: any)=>{
      console.log(res.data);
      this.ItemsArray= res.data;
    })  
  }

  onEdit(e, i){
    console.log(this.ItemsArray[i]);
    this.service.subject.next(this.ItemsArray[i]);
  }

}
